# -*- coding: utf-8 -*-
"""
Created on Sun Feb 11 01:26:56 2024

@author: menna
"""

# -*- coding: utf-8 -*-
"""
Created on Sat Feb 10 22:57:38 2024

@author: menna
"""

from pydantic import BaseModel

class BankNote(BaseModel):
    janruary:float
    february:float
    march:float
    april:float
    may:float
    june:float
    july:float
    augest:float
    septemper:float
    october:float
    november:float
    kind:float
    