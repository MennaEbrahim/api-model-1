# -*- coding: utf-8 -*-
"""
Created on Sun Feb 11 01:24:45 2024

@author: menna
"""

import uvicorn
from fastapi import FastAPI
from BankNotes import BankNote
import numpy as np
import pickle
import pandas as pd

app=FastAPI()
pickle_in=open("C:/Users/menna/app/model1.pkl","rb")
model=pickle.load(pickle_in)

@app.get('/')
def index():
    return {'message':'Hello,world'}

@app.get('/{name}')
def get_name(name: str):
    return {'welcome to my model': f'Hello,{name}'}

@app.post('/predict')
def predict_banknote(data:BankNote):
   data=data.dict()
   janruary=data['janruary']
   #print(janruary)
   february=data['february']
  # print(february)
   march=data['march']
  # print(march)
   april=data['april']
   #print(april)
   may=data['may']
   #print(may)
   june=data['june']
   #print(june)
   july=data['july']
   #print(july)
   augest=data['augest']
   #print(augest)
   septemper=data['septemper']
  # print(septemper)
   october=data['october']
  # print(october)
   november=data['november']
   #print(november)
   kind=data['kind']
   #print(kind)
   
   #print(Average)
   # print(model.predict([[janruary,february,march,april,may,june,july,augest,septemper,october,november,kind,Average]]))
  #  print("Hello")
   prediction=model.predict([[janruary,february,march,april,may,june,july,augest,septemper,october,november,kind]])
    
   return {"prediction": int(prediction[0])}

if __name__=='__main__':
    uvicorn.run(app,host='127.0.0.1',port=8001)
        



